package TextBasedGame;
public class Map{
    private String name;
    private String description;
    private Object[][] layout = new Object[10][5];
    public Map(Priest p){
        name = "Sky Cruiser Endeavor";
        description = "A sky ship has been invaded by a creepy one-eye lazer-beam shooting monster and " +
        "a dood with Napolean complex and fire wings!";
        layout[0][0] = p;//double check this, not sure if this is right
        layout[3][0] = new Perimos();
        layout[3][1] = new Perimos();
        layout[3][2] = new Perimos();
        layout[3][3] = new Perimos();
        layout[3][4] = new Perimos();
        layout[9][4] = new Darkan();
    }
    public Map(Lancer l){
        name = "Sky Cruiser Endeavor";
        description = "A sky ship has been invaded by a creepy one-eye lazer-beam shooting monster and " +
        "a dood with Napolean complex and fire wings!";
        layout[0][0] = l;//double check this, not sure if this is right
        layout[3][0] = new Perimos();
        layout[3][1] = new Perimos();
        layout[3][2] = new Perimos();
        layout[3][3] = new Perimos();
        layout[3][4] = new Perimos();
        layout[9][4] = new Darkan();
    }
    public Map(Sorcerer s){
        name = "Sky Cruiser Endeavor";
        description = "A sky ship has been invaded by a creepy one-eye lazer-beam shooting monster and " +
        "a dood with Napolean complex and fire wings!";
        layout[0][0] = s;//double check this, not sure if this is right
        layout[3][0] = new Perimos();
        layout[3][1] = new Perimos();
        layout[3][2] = new Perimos();
        layout[3][3] = new Perimos();
        layout[3][4] = new Perimos();
        layout[9][4] = new Darkan();
    }
}