public class HPB extends Location{
    public static final int HEALB = 250;
    
    public HPB(int x, int y){
        super ("Large Healthpack", "A healthpack that heals for 250 HP.", x, y);
    }
}