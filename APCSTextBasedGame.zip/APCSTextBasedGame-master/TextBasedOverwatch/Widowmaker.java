public class Widowmaker extends Character{
    public Widowmaker(){
        super ("Widowmaker", "A Blue OuiOuiBaguette Sniper", 200);
    }
}