public abstract class Map{
    private String name;
    private String description;
    private Object[] layout;
    
    public Map(){
        
    }
}