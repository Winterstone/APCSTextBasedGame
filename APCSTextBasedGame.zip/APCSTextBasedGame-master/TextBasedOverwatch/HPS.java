public class HPS extends Location{
    public static final int HEALS = 75;
    
    public HPS(int x, int y){
        super ("Small Healthpack", "A healthpack that heals for 75 HP.", x, y);
    }
}